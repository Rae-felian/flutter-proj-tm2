import 'package:flutter/material.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({Key? key}) : super(key: key);

  @override
  State<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  bool _showMoreNews = false;
  
  final List<String> _carouselImages = [
    'https://picsum.photos/3200/1500?random=101',
    'https://picsum.photos/3200/1500?random=102',
    'https://picsum.photos/3200/1500?random=103',
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Berita'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/products');
            },
            child: const Text('Produk', style: TextStyle(color: Colors.black)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/about');
            },
            child: const Text('Tentang Kami', style: TextStyle(color: Colors.black)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/news');
            },
            child: const Text('Berita', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Section 1: Custom Carousel dengan PageView
            Container(
              height: 500,
              child: Stack(
                children: [
                  // PageView untuk carousel
                  PageView.builder(
                    controller: _pageController,
                    itemCount: _carouselImages.length,
                    onPageChanged: (index) {
                      setState(() {
                        _currentPage = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      return Container(
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: NetworkImage(_carouselImages[index]),
                            fit: BoxFit.cover,
                          ),
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.transparent,
                                Colors.black.withOpacity(0.8),
                              ],
                              stops: const [0.6, 1.0],
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Berita Terkini',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  'Judul Berita Utama ${index + 1}',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                const Text(
                                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies in vitae libero.',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 20),
                                ElevatedButton(
                                  onPressed: () {},
                                  child: const Text('Baca Selengkapnya'),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  
                  // Left Navigation Arrow
                  Positioned(
                    left: 10,
                    top: 0,
                    bottom: 0,
                    child: Center(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
                          onPressed: () {
                            if (_currentPage > 0) {
                              _pageController.animateToPage(
                                _currentPage - 1,
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeInOut,
                              );
                            } else {
                              // Cycle to the last page if at the beginning
                              _pageController.animateToPage(
                                _carouselImages.length - 1,
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeInOut,
                              );
                            }
                          },
                        ),
                      ),
                    ),
                  ),
                  
                  // Right Navigation Arrow
                  Positioned(
                    right: 10,
                    top: 0,
                    bottom: 0,
                    child: Center(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.arrow_forward_ios, color: Colors.white),
                          onPressed: () {
                            if (_currentPage < _carouselImages.length - 1) {
                              _pageController.animateToPage(
                                _currentPage + 1,
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeInOut,
                              );
                            } else {
                              // Cycle to the first page if at the end
                              _pageController.animateToPage(
                                0,
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeInOut,
                              );
                            }
                          },
                        ),
                      ),
                    ),
                  ),
                  
                  // Indicator dots
                  Positioned(
                    bottom: 20,
                    left: 0,
                    right: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(_carouselImages.length, (index) {
                        return Container(
                          width: 12.0,
                          height: 12.0,
                          margin: const EdgeInsets.symmetric(horizontal: 4.0),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(
                              _currentPage == index ? 0.9 : 0.4,
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),

            // Section 2: News Grid 2x2
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Berita Terbaru',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  
                  const SizedBox(height: 30),
                  
                  // Row 1: First 2 news items
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // News Item 1
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // News Image
                            Container(
                              height: 200,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                image: const DecorationImage(
                                  image: NetworkImage('https://picsum.photos/2400/1600?random=1'),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            // News Title
                            const Text(
                              'Judul Berita 1',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            // News Description
                            const Text(
                              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies.',
                              style: TextStyle(fontSize: 14),
                            ),
                            const SizedBox(height: 12),
                            // Read More Button - Left aligned
                            Align(
                              alignment: Alignment.centerLeft,
                              child: ElevatedButton(
                                onPressed: () {},
                                child: const Text('Baca Selengkapnya'),
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(width: 20),
                      
                      // News Item 2
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // News Image
                            Container(
                              height: 200,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                image: const DecorationImage(
                                  image: NetworkImage('https://picsum.photos/2400/1600?random=2'),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            // News Title
                            const Text(
                              'Judul Berita 2',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            // News Description
                            const Text(
                              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies.',
                              style: TextStyle(fontSize: 14),
                            ),
                            const SizedBox(height: 12),
                            // Read More Button - Left aligned
                            Align(
                              alignment: Alignment.centerLeft,
                              child: ElevatedButton(
                                onPressed: () {},
                                child: const Text('Baca Selengkapnya'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 30),
                  
                  // Row 2: Second 2 news items
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // News Item 3
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // News Image
                            Container(
                              height: 200,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                image: const DecorationImage(
                                  image: NetworkImage('https://picsum.photos/2400/1600?random=3'),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            // News Title
                            const Text(
                              'Judul Berita 3',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            // News Description
                            const Text(
                              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies.',
                              style: TextStyle(fontSize: 14),
                            ),
                            const SizedBox(height: 12),
                            // Read More Button - Left aligned
                            Align(
                              alignment: Alignment.centerLeft,
                              child: ElevatedButton(
                                onPressed: () {},
                                child: const Text('Baca Selengkapnya'),
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(width: 20),
                      
                      // News Item 4
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // News Image
                            Container(
                              height: 200,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                image: const DecorationImage(
                                  image: NetworkImage('https://picsum.photos/2400/1600?random=4'),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            // News Title
                            const Text(
                              'Judul Berita 4',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            // News Description
                            const Text(
                              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies.',
                              style: TextStyle(fontSize: 14),
                            ),
                            const SizedBox(height: 12),
                            // Read More Button - Left aligned
                            Align(
                              alignment: Alignment.centerLeft,
                              child: ElevatedButton(
                                onPressed: () {},
                                child: const Text('Baca Selengkapnya'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 30),
                  
                  // Show More/Less Button - Left aligned
                  Align(
                    alignment: Alignment.center,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          _showMoreNews = !_showMoreNews;
                        });
                      },
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _showMoreNews ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                            size: 30,
                            color: Colors.blue,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            _showMoreNews ? 'Tampilkan Lebih Sedikit' : 'Tampilkan Lebih Banyak',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  // Additional News Items (Visible when Show More is clicked)
                  if (_showMoreNews) ...[
                    const SizedBox(height: 30),
                    
                    // Row 3: Third 2 news items
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // News Item 5
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // News Image
                              Container(
                                height: 200,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  image: const DecorationImage(
                                    image: NetworkImage('https://picsum.photos/2400/1600?random=5'),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              // News Title
                              const Text(
                                'Judul Berita 5',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              // News Description
                              const Text(
                                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies.',
                                style: TextStyle(fontSize: 14),
                              ),
                              const SizedBox(height: 12),
                              // Read More Button - Left aligned
                              Align(
                                alignment: Alignment.centerLeft,
                                child: ElevatedButton(
                                  onPressed: () {},
                                  child: const Text('Baca Selengkapnya'),
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        const SizedBox(width: 20),
                        
                        // News Item 6
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // News Image
                              Container(
                                height: 200,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  image: const DecorationImage(
                                    image: NetworkImage('https://picsum.photos/2400/1600?random=6'),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              // News Title
                              const Text(
                                'Judul Berita 6',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              // News Description
                              const Text(
                                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies.',
                                style: TextStyle(fontSize: 14),
                              ),
                              const SizedBox(height: 12),
                              // Read More Button - Left aligned
                              Align(
                                alignment: Alignment.centerLeft,
                                child: ElevatedButton(
                                  onPressed: () {},
                                  child: const Text('Baca Selengkapnya'),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 30),
                    
                    // Row 4: Fourth 2 news items
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // News Item 7
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // News Image
                              Container(
                                height: 200,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  image: const DecorationImage(
                                    image: NetworkImage('https://picsum.photos/2400/1600?random=7'),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              // News Title
                              const Text(
                                'Judul Berita 7',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              // News Description
                              const Text(
                                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies.',
                                style: TextStyle(fontSize: 14),
                              ),
                              const SizedBox(height: 12),
                              // Read More Button - Left aligned
                              Align(
                                alignment: Alignment.centerLeft,
                                child: ElevatedButton(
                                  onPressed: () {},
                                  child: const Text('Baca Selengkapnya'),
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        const SizedBox(width: 20),
                        
                        // News Item 8
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // News Image
                              Container(
                                height: 200,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  image: const DecorationImage(
                                    image: NetworkImage('https://picsum.photos/2400/1600?random=8'),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              // News Title
                              const Text(
                                'Judul Berita 8',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              // News Description
                              const Text(
                                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in metus vitae lectus ultrices ultricies.',
                                style: TextStyle(fontSize: 14),
                              ),
                              const SizedBox(height: 12),
                              // Read More Button - Left aligned
                              Align(
                                alignment: Alignment.centerLeft,
                                child: ElevatedButton(
                                  onPressed: () {},
                                  child: const Text('Baca Selengkapnya'),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),

            const SizedBox(height: 30),

           // Footer
            Container(
              padding: const EdgeInsets.all(16),
              color: Colors.white, 
              child: Column(
                children: [
                  // Text copyright
                  const Text(
                    '© 2025 Raeldy',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 15),

                  // Sosial media icons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Facebook icon
                      IconButton(
                        icon: const Icon(
                          Icons.facebook,
                          color: Colors.black,
                          size: 30,
                        ),
                        onPressed: () {
                          // Handle Facebook link
                        },
                      ),

                      const SizedBox(width: 20),

                      // Twitter/X icon
                      IconButton(
                        icon: const Icon(
                          Icons
                              .music_note, // Menggunakan icon lain untuk Twitter/X karena tidak ada bawaan
                          color: Colors.black,
                          size: 30,
                        ),
                        onPressed: () {
                          // Handle Twitter/X link
                        },
                      ),

                      const SizedBox(width: 20),

                      // YouTube icon
                      IconButton(
                        icon: const Icon(
                          Icons.play_circle_fill,
                          color: Colors.black,
                          size: 30,
                        ),
                        onPressed: () {
                          // Handle YouTube link
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

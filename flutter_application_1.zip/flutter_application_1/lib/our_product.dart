import 'package:flutter/material.dart';

class OurProduct extends StatelessWidget {
  const OurProduct({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Produk Kami'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/products');
            },
            child: const Text('Produk', style: TextStyle(color: Colors.black)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/about');
            },
            child: const Text('Tentang Kami', style: TextStyle(color: Colors.black)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/news');
            },
            child: const Text('Berita', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Section 1: Gambar dengan Overlay (sama seperti landing page)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16.0),
              height: 500,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                image: const DecorationImage(
                  image: NetworkImage('https://picsum.photos/3200/1500'),
                  fit: BoxFit.cover,
                ),
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 40),

            // Section 2: Tiga kolom dengan alternatif gambar-teks
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Our Products',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  
                  const SizedBox(height: 30),
                  
                  // Produk 1: Gambar di kiri, teks di kanan
                  Row(
                    children: [
                      // Gambar di sebelah kiri
                      Expanded(
                        flex: 1,
                        child: Container(
                          height: 250,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            image: const DecorationImage(
                              image: NetworkImage('https://picsum.photos/3200/3200?random=1'),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      // Teks di sebelah kanan
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Product 1',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 15),
                            const Text(
                              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                              style: TextStyle(fontSize: 16),
                            ),
                            const SizedBox(height: 20),
                            // Button di bawah teks
                            ElevatedButton(
                              onPressed: () {
                                // Button hanya sebagai # link
                              },
                              child: const Text('Learn More'),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 40),
                  
                  // Produk 2: Teks di kiri, gambar di kanan
                  Row(
                    children: [
                      // Teks di sebelah kiri
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Product 2',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 15),
                            const Text(
                              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                              style: TextStyle(fontSize: 16),
                            ),
                            const SizedBox(height: 20),
                            // Button di bawah teks
                            ElevatedButton(
                              onPressed: () {
                                // Button hanya sebagai # link
                              },
                              child: const Text('Learn More'),
                            )
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      // Gambar di sebelah kanan
                      Expanded(
                        flex: 1,
                        child: Container(
                          height: 250,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            image: const DecorationImage(
                              image: NetworkImage('https://picsum.photos/3200/3200?random=2'),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 40),
                  
                  // Produk 3: Gambar di kiri, teks di kanan
                  Row(
                    children: [
                      // Gambar di sebelah kiri
                      Expanded(
                        flex: 1,
                        child: Container(
                          height: 250,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            image: const DecorationImage(
                              image: NetworkImage('https://picsum.photos/3200/3200?random=3'),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      // Teks di sebelah kanan
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Product 3',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 15),
                            const Text(
                              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                              style: TextStyle(fontSize: 16),
                            ),
                            const SizedBox(height: 20),
                            // Button di bawah teks
                            ElevatedButton(
                              onPressed: () {
                                // Button hanya sebagai # link
                              },
                              child: const Text('Learn More'),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),

            // Section 3: Gambar dengan overlay heading di tengah tanpa button
            Stack(
              children: [
                // Gambar background
                Container(
                  height: 600,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage('https://picsum.photos/4800/3200?random=4'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                
                // Overlay gradien untuk memastikan teks dapat dibaca
                Container(
                  height: 600,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.7),
                      ],
                      stops: const [0.4, 1.0],
                    ),
                  ),
                ),
                
                // Container untuk heading dengan posisi absolut di center
                Positioned(
                  top: 0,
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Text(
                      'Premium Quality Products',
                      style: TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            offset: const Offset(1.0, 1.0),
                            blurRadius: 3.0,
                            color: Colors.black.withOpacity(0.8),
                          ),
                        ],
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),

            // Footer
            // Footer
            Container(
              padding: const EdgeInsets.all(16),
              color: Colors.white, 
              child: Column(
                children: [
                  // Text copyright
                  const Text(
                    '© 2025 Raeldy',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 15),

                  // Sosial media icons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Facebook icon
                      IconButton(
                        icon: const Icon(
                          Icons.facebook,
                          color: Colors.black,
                          size: 30,
                        ),
                        onPressed: () {
                          // Handle Facebook link
                        },
                      ),

                      const SizedBox(width: 20),

                      // Twitter/X icon
                      IconButton(
                        icon: const Icon(
                          Icons
                              .music_note, // Menggunakan icon lain untuk Tiktod karena tidak ada bawaan
                          color: Colors.black,
                          size: 30,
                        ),
                        onPressed: () {
                          // Handle Tiktod link
                        },
                      ),

                      const SizedBox(width: 20),

                      // YouTube icon
                      IconButton(
                        icon: const Icon(
                          Icons.play_circle_fill,
                          color: Colors.black,
                          size: 30,
                        ),
                        onPressed: () {
                          // Handle YouTube link
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

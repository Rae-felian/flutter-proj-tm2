import 'package:flutter/material.dart';
import 'landing_page.dart';
import 'our_product.dart';
import 'about.dart';
import 'news.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Landing Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const LandingPage(),
        '/products': (context) => const OurProduct(),
        '/about': (context) => const AboutPage(),
        '/news': (context) => const NewsPage(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}